#include <stdio.h>
#include<conio.h>
int main(){
	
	printf("$$ HAPPY DHANTERUS $$");
	
}

