#include <stdio.h>
#include <stdlib.h>
#define SIZE 5

int queue[SIZE]; // Array to hold the queue elements
int front = -1;  // Points to the front of the queue
int rear = -1;   // Points to the rear of the queue

// Function to enqueue an element into the queue
void enqueue(int value) {
    if (rear == SIZE - 1) {
        printf("Queue is Full! Enqueue operation failed.\n");
    } else {
        if (front == -1) {
            front = 0; // Initialize front if inserting the first element
        }
        queue[++rear] = value;
        printf("%d enqueued to the queue.\n", value);
    }
}

// Function to dequeue an element from the queue
void dequeue() {
    if (front == -1 || front > rear) {
        printf("Queue is Empty! Dequeue operation failed.\n");
    } else {
        printf("%d dequeued from the queue.\n", queue[front++]);
        if (front > rear) {
            // Reset queue when all elements are dequeued
            front = -1;
            rear = -1;
        }
    }
}

// Function to traverse and display the elements of the queue
void traverse() {
    if (front == -1 || front > rear) {
        printf("Queue is Empty!\n");
    } else {
        printf("Queue elements: ");
        for (int i = front; i <= rear; i++) {
            printf("%d ", queue[i]);
        }
        printf("\n");
    }
}

// Main function to test the queue operations
int main() {
    int choice, value;

    while (1) {
        printf("\nQueue Operations:\n");
        printf("1. Enqueue\n");
        printf("2. Dequeue\n");
        printf("3. Traverse\n");
        printf("4. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                printf("Enter value to enqueue: ");
                scanf("%d", &value);
                enqueue(value);
                break;
            case 2:
                dequeue();
                break;
            case 3:
                traverse();
                break;
            case 4:
                exit(0);
            default:
                printf("Invalid choice! Please try again.\n");
        }
    }

    return 0;
}

